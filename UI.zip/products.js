// products array
let products = [
  {
    name: "Macbook 1",
    price: 100,
    src: "./img/lp2.jpg",
  },
  {
    name: "Macbook 2",
    price: 200,
    src: "./img/lp3.jpg",
  },
  {
    name: "Macbook 3",
    price: 300,
    src: "./img/lp4.jpg",
  },
  {
    name: "Macbook 4",
    price: 400,
    src: "./img/lp5.jpg",
  },
];
